HDL for RS-232 style serial interface to download parameters to FPGA registers.
Read/write messages with 16-bit address and 32-bit data fields
